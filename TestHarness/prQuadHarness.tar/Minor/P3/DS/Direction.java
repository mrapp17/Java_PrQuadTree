package Minor.P3.DS;

public enum Direction {NW, SW, SE, NE, NOQUADRANT};
